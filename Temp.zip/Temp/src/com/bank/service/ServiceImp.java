package com.bank.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.bank.bean.Customer;
import com.bank.bean.Passbook;
import com.bank.dao.DaoImpl;
import com.bank.exceprtion.CustomerNotFound;

public  class ServiceImp implements ServiceInterface  {
	
	DaoImpl dao=new DaoImpl();
	
	public boolean validatePhno(String mobileno)
	{
		boolean flag = false;
	    Pattern pattern = Pattern.compile("^(0/91)?[7-9][0-9]{9}");
	    Matcher matcher = pattern.matcher(mobileno);
	    if(matcher.matches())
	    {
	        flag=true;
	    }
		return flag;	
	}
	public boolean validateName(String name)
	{
		boolean flag = false;
		if(name.matches("^[A-Za-z\\s]+$"))
		{
			flag = true;
		}
		return flag;	
	}
	public boolean validateAge(int age)
	{
		boolean flag = false;
		if(age>18 && age<100)
		{
			flag = true;
		}
		return flag;	
	}
	public boolean validatePan(String panno)
	{
		boolean flag = false;
		if(panno.matches("^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}"))
		{
			flag = true;
		}
		return flag;	
	}
	 public boolean validateMail(String email)
	 {
		 boolean flag=false;
		 if(email.matches("^[_a-zA-Z0-9-]+(\\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*([a-zA-Z]{2,3})"))
		 {
			 flag=true;
		 }
		 return flag;
		 
	 }
	
public boolean validateDate(Customer c) {
		boolean flag=false;
		Pattern p=Pattern.compile("A-Za-z");
		Matcher m=p.matcher(c.getName());
		 boolean a=m.matches();
		 Pattern p1=Pattern.compile("[1-9][0-9]{9}");
			Matcher m1=p1.matcher(c.getMobileno());
			 boolean b =m1.matches();
			Pattern p3=Pattern.compile("hyd");
				Matcher m3=p3.matcher(c.getAddress());
				 boolean d=m3.matches();
		// TODO Auto-generated method stub
		 if(a&&b&&d){
			  flag=true;
		 }
		 return flag;
	}
/*public Customer displayCust(int accNumber) {
	return dao.displayCust(accNumber);
}
*/


/*
	public int withDraw(Customer c,int withdraw) {
		// TODO Auto-generated method stub
		if(c.getCurrBal()-withdraw>500)
		{
			withdraw=(int) (c.getCurrBal()-withdraw);
			
		// TODO Auto-generated method stub
			
		
	
		}*/
	
	/*return dao.withDraw(c,withdraw);
	}
*/
	@Override
	public boolean addCustomer(Customer c) throws CustomerNotFound {
		// TODO Auto-generated method stub
		return dao.addCustomer(c);
	}


/*
	public boolean validAccountNo(String email,int accNumber,int pin)
	{
	return	dao.validAccountNo(email,accNumber,pin);
		// TODO Auto-generated method stub
		
	}
	*/


	/*@Override
	public int showBalance(Customer c,int accNumber1) {
		// TODO Auto-generated method stub
		return dao.showBalance(c,accNumber1);
	}
*/




	/*public boolean verifyAcc(String email4, int accNumber4) {
		// TODO Auto-generated method stub
		return dao.verifyAcc(email4, accNumber4);
	}*/
	/*@Override
	public boolean fundTransfer(String email3, int accNumber3, int pin3, Customer a, Customer b, String email4,
			int accNumber4, int amount) {
		// TODO Auto-generated method stub
		return fundTransfer(email3,accNumber3,pin3,a,b,email4,accNumber4,amount);
	}*/
	/*@Override
	public boolean validatedeposit(int deposit) {
		// TODO Auto-generated method stub
		return dao.validatedeposit(deposit);
	}*/
	/*@Override
	public void updateCustomer(Customer c,int amount) throws CustomerNotFound {
		// TODO Auto-generated method stub
		 dao.updateCustomer(c,amount);
		
	}*/
	@Override
	public Customer getCustomerDetails(int accNumber2, String email, int pin)
			throws CustomerNotFound {
		// TODO Auto-generated method stub
		return dao.getCustomerDetails(accNumber2,email,pin);
	}
	@Override
	public boolean deposit(int accNumber2,Double deposit) throws CustomerNotFound {
		
		
		
		return dao.deposit(accNumber2,deposit);
	}
	@Override
	public boolean validateAmount(Double withdraw) {
		// TODO Auto-generated method stub
		return dao.validateAmount(withdraw);
	}
	@Override
	public boolean withdraw(int accNumber, 
			Double withdraw) throws CustomerNotFound {
		// TODO Auto-generated method stub
		return dao.withdraw(accNumber,withdraw);
	}
	@Override
	public boolean verifyDetails(String email1, int accNumber1, int pin1)
			throws CustomerNotFound {
		// TODO Auto-generated method stub
		return dao.verifyDetails(email1,accNumber1,pin1);
	}
	@Override
	public Double showBalance(int accNumber1) throws CustomerNotFound {
		// TODO Auto-generated method stub
		return dao.showBalance(accNumber1);
	}
	@Override
	public boolean verifyAccno(int accNumber4,String email4) throws CustomerNotFound {
		// TODO Auto-generated method stub
		return dao.verifyAccno(accNumber4,email4);
	}
	@Override
	public boolean fundTransfer(int accNumber3, int accNumber4, Double amount)
			throws CustomerNotFound {
		// TODO Auto-generated method stub
		return dao.fundTransfer(accNumber3,accNumber4,amount);
	}
	/*@Override
	public boolean printTransaction(int accNumber4) throws CustomerNotFound {
		// TODO Auto-generated method stub
		return false;
	}
	*/
	@Override
	public List<Passbook> printTransaction(int accountNumber)
			throws CustomerNotFound {
		// TODO Auto-generated method stub
		return dao.printTransaction(accountNumber);
	}
	


}